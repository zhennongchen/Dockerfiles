#!/bin/bash

sudo docker build -t zc_pytorch:2.0 .
