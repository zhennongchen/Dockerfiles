#!/bin/bash

sudo docker build -t pytorch:3.0 .
